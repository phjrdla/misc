connect / as sysdba;

alter database mount;
alter database open;

exit
