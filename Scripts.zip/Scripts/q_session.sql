select sid, username, state, status from v$session
/
